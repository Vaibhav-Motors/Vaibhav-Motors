from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required # Mechanic ke liye
from .forms import BookingForm
from .models import Booking
from django.contrib.auth.models import User

# 1. Booking Service View
@login_required
def booking_service(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking_instance = form.save(commit=False)
            booking_instance.user = request.user
            booking_instance.save()
            messages.success(request, 'Booking Successful! We will contact you soon.')
            return redirect('customer_dashboard')
        else:
            messages.error(request, 'Error in booking. Please check details.')
    
    form = BookingForm()
    return render(request, 'bookingg.html', {'form': form})

# 2. Customer Dashboard View
@login_required
def dashboard_view(request):
    display_name = request.user.first_name
    # User ki apni bookings
    customer_bookings = Booking.objects.filter(user=request.user).order_by('-appointment_date', '-appointment_time')
    
    context = {
        'bookings': customer_bookings,
        'username': display_name
    }
    return render(request, 'dashboard.html', context)

# --- 3. MECHANIC DASHBOARD (Sirf Staff Ke Liye) ---
@staff_member_required
def mechanic_dashboard(request):
    # Saari bookings dikhegi (Pending upar)
    bookings = Booking.objects.all().order_by('-id')
    return render(request, 'mechanic_dashboard.html', {'bookings': bookings})

# --- 4. UPDATE STATUS LOGIC ---
@staff_member_required
def update_booking_status(request, booking_id):
    if request.method == 'POST':
        booking = get_object_or_404(Booking, id=booking_id)
        new_status = request.POST.get('status')
        
        if new_status:
            booking.status = new_status
            booking.save()
            messages.success(request, f"Status updated to {new_status}")
            
    return redirect('mechanic_dashboard')

@staff_member_required
def mechanic_dashboard(request):
    # Saari bookings fetch karein
    all_bookings = Booking.objects.all().order_by('-id')
    
    # Stats calculate karein stats cards ke liye
    stats = {
        'total': all_bookings.count(),
        'pending': all_bookings.filter(status='Pending').count(),
        'confirmed': all_bookings.filter(status='In Progress').count(),
        'completed': all_bookings.filter(status='Done').count(),
    }
    
    # Filter logic (Tabs ke liye)
    status_filter = request.GET.get('tab', 'Pending') # Default pending tab khulega
    filtered_bookings = all_bookings.filter(status=status_filter)

    context = {
        'bookings': filtered_bookings,
        'stats': stats,
        'current_tab': status_filter,
    }
    return render(request, 'mechanic_dashboard.html', context)    

