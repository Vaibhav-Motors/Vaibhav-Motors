# booking/forms.py

from django import forms
from .models import Booking

class BookingForm(forms.ModelForm):
    # Agar aapko date aur time fields ke liye custom widgets chahiye, toh yahan add karein
    appointment_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'})
    )
    appointment_time = forms.TimeField(
        widget=forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'})
    )
    
    class Meta:
        model = Booking
        fields = [
            'customer_name', 
            'customer_email', 
            'customer_phone',
            'vehicle_type', 
            'service_type', 
            'appointment_date', 
            'appointment_time'
        ]
        # Aap fields ke liye yahan custom labels ya widgets bhi define kar sakte hain
        widgets = {
            'customer_name': forms.TextInput(attrs={'placeholder': 'Enter your full name'}),
            'customer_email': forms.EmailInput(attrs={'placeholder': 'Enter your email'}),
            # Baaki fields ke liye bhi classes ya attributes add kiye ja sakte hain
        }