from django.db import models
from django.conf import settings

class Booking(models.Model):
    # Customer Details
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='bookings'
    )
    
    customer_name = models.CharField(max_length=100)
    customer_email = models.EmailField()
    customer_phone = models.CharField(max_length=15, blank=True, null=True)

    # Appointment Details
    VEHICLE_CHOICES = [
        ('Car', 'Car'),
        ('Bike', 'Bike'),
        ('Other', 'Other'),
    ]
    vehicle_type = models.CharField(max_length=10, choices=VEHICLE_CHOICES, default='Car')
    
    SERVICE_CHOICES = [
        ('Full Service', 'Full Service'),
        ('Oil Change', 'Oil Change'),
        ('Tire Rotation', 'Tire Rotation'),
        ('General Repair', 'General Repair'),
    ]
    service_type = models.CharField(max_length=50, choices=SERVICE_CHOICES)
    
    appointment_date = models.DateField()
    appointment_time = models.TimeField()
    
    # --- Status Field Added Here ---
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('In Progress', 'In Progress'),
        ('Done', 'Done'),
        ('Cancelled', 'Cancelled'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    
    created_at = models.DateTimeField(auto_now_add=True)
    is_confirmed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.customer_name} - {self.status}"