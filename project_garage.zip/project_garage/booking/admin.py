# booking/admin.py
from django.contrib import admin
from  booking.models import Booking  # Aapka booking model name

admin.site.register(Booking)