from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

# Import views
from garage.views import home 
from booking import views
from booking.views import booking_service, dashboard_view, mechanic_dashboard, update_booking_status
from Otp.views import login_view, logout_view, register_view, verify_otp
from vehicleapp.views import add_vehicle, admin_customers_list, vehicle_list, edit_vehicle, delete_vehicle, get_vehicle_count

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),
    
    # Home page
    path('', home, name='home'),
    
    # Authentication (OTP based)
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('verify-otp/', verify_otp, name='verify_otp'),  
    path('register/', register_view, name='register'),
    
    # Vehicle URLs
    path('vehicles/add/', add_vehicle, name='add_vehicle'),
    path('vehicles/list/', vehicle_list, name='vehicle_list'),
    path('vehicles/edit/<int:vehicle_id>/', edit_vehicle, name='edit_vehicle'),
    path('vehicles/delete/<int:vehicle_id>/', delete_vehicle, name='delete_vehicle'),
    path('vehicles/count/', get_vehicle_count, name='vehicle_count'),

    # Booking & Customer Dashboard
    path('booking/', booking_service, name='booking_service'),
    path('dashboard/', dashboard_view, name='customer_dashboard'),

    # --- MECHANIC SECTION (NEW) ---
    path('mechanic/dashboard/', mechanic_dashboard, name='mechanic_dashboard'),
    path('mechanic/update/<int:booking_id>/', update_booking_status, name='update_status'),
    path('admin-customers/', admin_customers_list, name='admin_customers'),
]

# Static & Media files
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)