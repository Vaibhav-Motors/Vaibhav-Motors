from django.shortcuts import render


def home(request):
    # सीधे फाइल का नाम लिखें
    return render(request,'home.html')

