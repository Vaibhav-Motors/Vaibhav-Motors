from django import forms
from .models import Vehicle
from django.core.exceptions import ValidationError
import re
from datetime import datetime # Required for clean_year validation

class VehicleForm(forms.ModelForm):
    # Add Manufacturing Year field for better control, using IntegerField
    manufacturing_year = forms.IntegerField(
        label='Manufacturing Year',
        widget=forms.Select(choices=[]), # Will be populated by JS/Template
        required=True
    )
    
    class Meta:
        model = Vehicle
        fields = [
            'registration_number', 'make', 'model', 'variant', 'manufacturing_year', # Added 'variant', 'manufacturing_year'
             'fuel_type', 'transmission_type',
             'chassis_number', 'insurance_expiry',
        ]
        widgets = {
            # Removed default widget for 'make' and 'model' so we can use custom select/logic if needed.
            # Keeping the rest
            'insurance_expiry': forms.DateInput(attrs={'type': 'date'}),
           
        }
    
    # Cleaners (as per existing logic and new field logic)
    def clean_registration_number(self):
        reg_number = self.cleaned_data['registration_number']
        # Basic validation for Indian registration number format
        pattern = r'^[A-Z]{2}[0-9]{2}[A-Z]{0,2}[0-9]{4}$'
        if not re.match(pattern, reg_number.replace(' ', '').upper()):
            # Using the exact same validation as your forms.py
            raise ValidationError('Enter a valid registration number (e.g., MH12AB1234)')
        return reg_number.upper()
    
    # We will rename clean_year to clean_manufacturing_year if needed, 
    # but since the field is IntegerField now, let's update the validation.
    def clean_manufacturing_year(self):
        year = self.cleaned_data['manufacturing_year']
        current_year = datetime.now().year
        if year < 1900 or year > current_year + 1:
            raise ValidationError(f'Year must be between 1900 and {current_year + 1}')
        return year

    # The existing 'clean_year' logic is removed as the field name changed/updated.

    # Initialize the form fields with custom widgets/choices if needed
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Populate years dynamically for manufacturing_year field
        current_year = datetime.now().year
        YEAR_CHOICES = [(y, y) for y in range(current_year + 1, 1999, -1)]
        self.fields['manufacturing_year'].widget.choices = [('', 'Select Year')] + YEAR_CHOICES
        
        # Override default widgets for 'make' and 'model' to use standard Django form inputs
        self.fields['make'].widget = forms.TextInput(attrs={'placeholder': 'e.g., Maruti, Hyundai'})
        self.fields['model'].widget = forms.TextInput(attrs={'placeholder': 'e.g., Swift, Creta'})