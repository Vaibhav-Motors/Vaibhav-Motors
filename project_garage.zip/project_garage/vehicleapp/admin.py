# vehicleapp/admin.py
from django.contrib import admin
from vehicleapp.models import Vehicle  # Ensure karein aapka model name 'Vehicle' hi hai

admin.site.register(Vehicle)