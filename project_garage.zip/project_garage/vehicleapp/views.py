from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User # FIX 1: Import added
from django.contrib import messages
from django.http import JsonResponse
from .models import Vehicle
from .forms import VehicleForm
from datetime import datetime

@login_required
def add_vehicle(request):
    # FIX 2: changed 'owner' to 'user'
    vehicle_count = Vehicle.objects.filter(user=request.user).count()
    if vehicle_count >= 5:
        messages.warning(request, 'You can only register up to 5 vehicles.')
        return redirect('vehicle_list')
    
    if request.method == 'POST':
        form = VehicleForm(request.POST)
        if form.is_valid():
            vehicle = form.save(commit=False)
            vehicle.user = request.user # FIX 2: changed 'owner' to 'user'
            vehicle.save()
            messages.success(request, 'Vehicle registered successfully!')
            return redirect('vehicle_list')
    else:
        form = VehicleForm()
    
    return render(request, 'add_vehicle.html', {
        'form': form,
        'vehicle_count': vehicle_count
    })

@login_required
def vehicle_list(request):
    # FIX 2: changed 'owner' to 'user'
    vehicles = Vehicle.objects.filter(user=request.user)
    
    today = datetime.now().date()
    for vehicle in vehicles:
        vehicle.is_insurance_expired = vehicle.insurance_expiry < today if vehicle.insurance_expiry else False
    
    return render(request, 'vehicle_list.html', {
        'vehicles': vehicles
    })

@login_required
def edit_vehicle(request, vehicle_id):
    # FIX 2: changed 'owner' to 'user'
    vehicle = get_object_or_404(Vehicle, id=vehicle_id, user=request.user)
    
    if request.method == 'POST':
        form = VehicleForm(request.POST, instance=vehicle)
        if form.is_valid():
            form.save()
            messages.success(request, 'Vehicle details updated successfully!')
            return redirect('vehicle_list')
    else:
        form = VehicleForm(instance=vehicle)
    
    return render(request, 'edit_vehicle.html', {
        'form': form,
        'vehicle': vehicle
    })

@login_required
def delete_vehicle(request, vehicle_id):
    if request.method == 'POST':
        # FIX 2: changed 'owner' to 'user'
        vehicle = get_object_or_404(Vehicle, id=vehicle_id, user=request.user)
        vehicle.delete()
        messages.success(request, 'Vehicle deleted successfully!')
    return redirect('vehicle_list')

# Admin View
def admin_customers_list(request):
    # Yeh tabhi kaam karega jab models.py me user field me related_name='vehicles' hoga
    customers = User.objects.filter(is_staff=False).prefetch_related('vehicles') 
    return render(request, 'admin_customers.html', {'customers': customers})

# vehicleapp/views.py mein ye function add karein
@login_required
def get_vehicle_count(request):
    count = Vehicle.objects.filter(user=request.user).count() # 'owner' ki jagah 'user'
    return JsonResponse({'count': count})