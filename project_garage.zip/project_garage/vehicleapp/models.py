from django.db import models
from django.conf import settings
from django.contrib.auth.models import User

class Vehicle(models.Model):
    FUEL_TYPES = [
        ('Petrol', 'Petrol'),
        ('Diesel', 'Diesel'),
        ('CNG', 'CNG'),
        ('Electric', 'Electric'),
        ('Hybrid', 'Hybrid'),
    ]
    
    TRANSMISSION_TYPES = [
        ('Manual', 'Manual'),
        ('Automatic', 'Automatic'),
        ('Semi-Automatic', 'Semi-Automatic'),
    ]
    
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='vehicles' # Yeh zaroori hai details dikhane ke liye
    )
    registration_number = models.CharField(max_length=20, unique=True)
    make = models.CharField(max_length=50)
    model = models.CharField(max_length=50)

    # year = models.IntegerField()
    variant = models.CharField(max_length=50, verbose_name='Vehicle Variant', )
    manufacturing_year = models.IntegerField(verbose_name='Manufacturing Year', null=True, blank=True)
    
    # color = models.CharField(max_length=30)
    fuel_type = models.CharField(max_length=20, choices=FUEL_TYPES)
    transmission_type = models.CharField(max_length=20, choices=TRANSMISSION_TYPES)

    # engine_number = models.CharField(max_length=50)
    chassis_number = models.CharField(max_length=50)
    insurance_expiry = models.DateField()
    registration_date = models.DateTimeField(auto_now_add=True)
    
    # last_service_date = models.DateField(null=True, blank=True)
    # next_service_date = models.DateField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.make} {self.model} - {self.registration_number}"
    
    class Meta:
        ordering = ['-registration_date']

        # models.py में add करें
from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    profile_picture = models.ImageField(upload_to='profile_pics/', null=True, blank=True)
    phone_number = models.CharField(max_length=15, blank=True)
    
    def __str__(self):
        return self.user.username