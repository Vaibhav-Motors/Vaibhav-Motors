// ===== MOBILE MENU TOGGLE =====
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const navList = document.querySelector('.nav-list'); // We will toggle active on nav-list for styling

if (mobileMenuBtn && navList) {
    mobileMenuBtn.addEventListener('click', () => {
        navList.classList.toggle('active'); // Toggle class on nav-list
        mobileMenuBtn.innerHTML = navList.classList.contains('active') 
            ? '<i class="fas fa-times"></i>' 
            : '<i class="fas fa-bars"></i>';
    });
}

// Close mobile menu when clicking on a nav link
const navLinks = document.querySelectorAll('.nav-link');
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        if (navList.classList.contains('active')) {
            navList.classList.remove('active');
            mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
        }
    });
});

// ===== USER DROPDOWN TOGGLE (NEW) =====
const userDropdown = document.querySelector('.user-dropdown');
if (userDropdown) {
    // Toggle on click 
    userDropdown.addEventListener('click', function(e) {
        e.stopPropagation();
        this.classList.toggle('active');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!userDropdown.contains(e.target)) {
            userDropdown.classList.remove('active');
        }
    });
}


// ===== SMOOTH SCROLLING =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        // Only prevent default if it's strictly an anchor link, not just a hash
        const targetId = this.getAttribute('href');
        if (targetId === '#' || targetId === '') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            e.preventDefault();
            window.scrollTo({
                top: targetElement.offsetTop - 80, // Adjust for fixed header height
                behavior: 'smooth'
            });
        }
    });
});

// ===== HEADER SCROLL EFFECT =====
window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    if (header) {
        if (window.scrollY > 50) {
            header.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
        } else {
            header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.452)';
        }
    }
});

// ===== SERVICE CARD EXPAND FUNCTIONALITY (UNCHANGED) =====
document.querySelectorAll('.expand-btn').forEach(button => {
    button.addEventListener('click', function(e) {
        e.stopPropagation();
        const card = this.closest('.service-card');
        card.classList.toggle('expanded');
        
        const btnText = this.querySelector('.btn-text');
        if (btnText) {
            btnText.textContent = card.classList.contains('expanded') ? 'Show Less' : 'Read More';
        }
    });
});

// ===== SUPPORT MODAL FUNCTIONALITY (UNCHANGED) =====
const supportBtn = document.getElementById('supportBtn');
const supportModal = document.getElementById('supportModal');
const closeModal = document.getElementById('closeModal');

if (supportBtn && supportModal) {
    // Open support modal
    supportBtn.addEventListener('click', () => {
        supportModal.classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent background scrolling
    });

    // Close support modal
    if (closeModal) {
        closeModal.addEventListener('click', () => {
            supportModal.classList.remove('active');
            document.body.style.overflow = ''; // Restore scrolling
        });
    }

    // Close modal when clicking outside
    supportModal.addEventListener('click', (e) => {
        if (e.target === supportModal) {
            supportModal.classList.remove('active');
            document.body.style.overflow = '';
        }
    });

    // Close modal with Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && supportModal.classList.contains('active')) {
            supportModal.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
}