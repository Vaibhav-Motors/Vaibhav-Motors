from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login, logout
from django.core.mail import send_mail
from django.contrib import messages
from django.conf import settings  # <--- Ye line zaroor add karein
import random

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return render(request, 'login.html', {'error': 'Email not registered.'})

        otp = str(random.randint(100000, 999999))
        request.session['otp'] = otp
        request.session['email'] = email
        
        try:
            send_mail(
                'Login OTP - Vaibhav Motors',
                f'Hello {user.first_name},\n\nYour Login OTP is: {otp}',
                settings.EMAIL_HOST_USER,  # <--- Ab ye settings wala email use karega (Vishal wala)
                [email],
                fail_silently=False,
            )
        except Exception as e:
            print(e) # Error console me dekhne ke liye
            return render(request, 'login.html', {'error': 'System Error: Email not sent.'})
            
        return redirect('verify_otp')

    return render(request, 'login.html')


# 2. Verify OTP View
# Otp/views.py mein verify_otp function update karein
def verify_otp(request):
    if request.method == 'POST':
        user_otp = request.POST.get('otp')
        session_otp = request.session.get('otp')
        email = request.session.get('email')

        if session_otp and user_otp == session_otp:
            user = User.objects.get(email=email)
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            
            # .pop() use karein taaki agar key na ho toh error na aaye
            request.session.pop('otp', None) 
            request.session.pop('email', None)
            
            return redirect('home')
        else:
            return render(request, 'verify_otp.html', {'error': 'Invalid OTP. Please try again.'})

    return render(request, 'verify_otp.html')
# 3. Register View (NO PASSWORD LOGIC)
def register_view(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile') # Using mobile as username

        # Check if email already exists
        if User.objects.filter(email=email).exists():
            return render(request, 'register.html', {'error': 'Email already registered'})

        # Check if mobile (username) already exists
        if User.objects.filter(username=mobile).exists():
            return render(request, 'register.html', {'error': 'Mobile number already registered'})

        try:
            # Create user without password
            user = User.objects.create_user(username=mobile, email=email)
            user.first_name = first_name
            user.last_name = last_name
            
            # Set unusable password (since we use OTP)
            user.set_unusable_password()
            user.save()
            
            messages.success(request, "Registration Successful! Please Login.")
            return redirect('login')
            
        except Exception as e:
            return render(request, 'register.html', {'error': f'Error: {str(e)}'})

    return render(request, 'register.html')

# 4. Home View
def home_view(request):
    return render(request, 'home.html')

# 5. Logout View (FIXED)
def logout_view(request):
    logout(request) # <--- Ye sahi function hai
    return redirect('home')