from django.contrib import admin

# Abhi ke liye yahan kuch register karne ki zaroorat nahi hai 
# kyunki 'User' model pehle se hi Admin mein hota hai.