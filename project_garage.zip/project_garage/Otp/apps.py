from django.apps import AppConfig


class OtpConfig(AppConfig):
    name = 'Otp'
